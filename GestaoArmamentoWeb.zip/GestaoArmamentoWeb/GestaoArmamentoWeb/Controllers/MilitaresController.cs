﻿using GestaoArmamentoWeb.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using System.Collections.Generic;
using System.Data; // Necessário para Stored Procedures

namespace GestaoArmamentoWeb.Controllers
{
    public class MilitaresController : Controller
    {
        string connectionString = "Server=DESKTOP-EL5VTH4;Database=GestaoArmamento;Trusted_Connection=True;MultipleActiveResultSets=true;TrustServerCertificate=True";

        // 1. LISTAR MILITARES
        public IActionResult Index()
        {
            List<Militar> lista = new List<Militar>();

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                // Query com JOIN para mostrar a Unidade e o Username
                string sql = @"
                    SELECT M.id_militar, M.nome, U.nome as nome_unidade, Ut.username, Ut.email
                    FROM Militar M
                    JOIN Unidade_Militar U ON M.id_unidade = U.id_unidade
                    JOIN Utilizador Ut ON M.id_utilizador = Ut.id_utilizador";

                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Militar m = new Militar();
                            m.id_militar = (int)reader["id_militar"];
                            m.nome = reader["nome"].ToString();
                            m.nome_unidade = reader["nome_unidade"].ToString();
                            m.username = reader["username"].ToString();
                            m.email = reader["email"].ToString();
                            lista.Add(m);
                        }
                    }
                }
            }
            return View(lista);
        }

        // 2. INSERIR USANDO STORED PROCEDURE (Requisito do Professor)
        [HttpPost]
        public IActionResult AdicionarMilitar(string nome, int id_unidade, string username, string password, string email)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();

                    // Aqui dizemos que vamos usar uma STORED PROCEDURE
                    using (SqlCommand cmd = new SqlCommand("sp_RegistarMilitarComLogin", conn))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;

                        // Passamos os parâmetros que a Procedure pede
                        cmd.Parameters.AddWithValue("@Nome", nome);
                        cmd.Parameters.AddWithValue("@IdUnidade", id_unidade);
                        cmd.Parameters.AddWithValue("@Username", username);
                        cmd.Parameters.AddWithValue("@Password", password); // Em projeto real, devia ser encriptada!
                        cmd.Parameters.AddWithValue("@Email", email);

                        cmd.ExecuteNonQuery();
                    }
                }
            }
            catch (System.Exception ex)
            {
                System.Diagnostics.Debug.WriteLine("Erro SP: " + ex.Message);
            }

            return RedirectToAction("Index");
        }
        // 3. EDITAR (UPDATE)
        [HttpPost]
        public IActionResult EditarMilitar(int id_militar_edit, string nome_edit, int id_unidade_edit)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    // Query simples de UPDATE
                    string sql = @"UPDATE Militar 
                           SET nome = @nome, id_unidade = @unidade 
                           WHERE id_militar = @id";

                    using (SqlCommand cmd = new SqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@id", id_militar_edit);
                        cmd.Parameters.AddWithValue("@nome", nome_edit);
                        cmd.Parameters.AddWithValue("@unidade", id_unidade_edit);

                        cmd.ExecuteNonQuery();
                    }
                }
            }
            catch (System.Exception ex)
            {
                System.Diagnostics.Debug.WriteLine("Erro Update: " + ex.Message);
            }

            return RedirectToAction("Index");
        }
    }
}