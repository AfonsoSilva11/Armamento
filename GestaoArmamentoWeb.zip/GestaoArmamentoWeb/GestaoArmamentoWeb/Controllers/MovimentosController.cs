using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using GestaoArmamentoWeb.Models;
using System.Collections.Generic;

namespace GestaoArmamentoWeb.Controllers
{
    public class MovimentosController : Controller
    {
        string connectionString = "Server=DESKTOP-EL5VTH4;Database=GestaoArmamento;Trusted_Connection=True;MultipleActiveResultSets=true;TrustServerCertificate=True";

        // 1. CARREGAR A P�GINA COM AS LISTAS (Dropdowns)
        public IActionResult Index()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                // Buscar Armas para preencher o select
                List<Arma> armas = new List<Arma>();
                // S� mostramos armas que n�o foram abatidas, por exemplo
                string sqlArmas = "SELECT id_arma, numero_serie, estado FROM Arma";
                SqlCommand cmdArmas = new SqlCommand(sqlArmas, conn);

                using (SqlDataReader r1 = cmdArmas.ExecuteReader())
                {
                    while (r1.Read())
                    {
                        armas.Add(new Arma
                        {
                            id_arma = (int)r1["id_arma"],
                            numero_serie = (int)r1["numero_serie"],
                            estado = r1["estado"].ToString()
                        });
                    }
                }
                ViewBag.ListaArmas = armas;

                // Buscar Unidades para preencher o select de destino
                List<string[]> unidades = new List<string[]>();
                string sqlUnid = "SELECT id_unidade, nome FROM Unidade_Militar";
                SqlCommand cmdUnid = new SqlCommand(sqlUnid, conn);

                using (SqlDataReader r2 = cmdUnid.ExecuteReader())
                {
                    while (r2.Read())
                    {
                        // Guardamos ID e Nome num array simples
                        unidades.Add(new string[] { r2["id_unidade"].ToString(), r2["nome"].ToString() });
                    }
                }
                ViewBag.ListaUnidades = unidades;
            }

            return View();
        }

        // 2. EXECUTAR A TRANSFER�NCIA (TRANSA��O SQL)
        [HttpPost]
        public IActionResult RegistarMovimento(int id_arma, int id_destino, string tipo_movimento)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlTransaction transaction = conn.BeginTransaction();

                try
                {
                    // A. Descobrir onde a arma est� agora (Origem)
                    int id_origem = 0;
                    SqlCommand cmdGetOrigem = new SqlCommand("SELECT id_unidade FROM Arma WHERE id_arma = @id", conn, transaction);
                    cmdGetOrigem.Parameters.AddWithValue("@id", id_arma);

                    object result = cmdGetOrigem.ExecuteScalar();
                    if (result != null) id_origem = (int)result;

                    // B. Inserir no Hist�rico de Movimentos
                    string sqlMov = @"INSERT INTO Movimento_Armamento 
                                    (id_arma, tipo_movimento, id_origem, id_destino, data_movimento, autorizacao) 
                                    VALUES (@arma, @tipo, @origem, @destino, GETDATE(), 1)";

                    SqlCommand cmdMov = new SqlCommand(sqlMov, conn, transaction);
                    cmdMov.Parameters.AddWithValue("@arma", id_arma);
                    cmdMov.Parameters.AddWithValue("@tipo", tipo_movimento);
                    cmdMov.Parameters.AddWithValue("@origem", id_origem);
                    cmdMov.Parameters.AddWithValue("@destino", id_destino);
                    cmdMov.ExecuteNonQuery();

                    // C. Atualizar a localiza��o real da Arma na tabela principal
                    string sqlUpdate = "UPDATE Arma SET id_unidade = @destino WHERE id_arma = @arma";
                    SqlCommand cmdUpd = new SqlCommand(sqlUpdate, conn, transaction);
                    cmdUpd.Parameters.AddWithValue("@destino", id_destino);
                    cmdUpd.Parameters.AddWithValue("@arma", id_arma);
                    cmdUpd.ExecuteNonQuery();

                    // Se tudo correu bem, GRAVAR!
                    transaction.Commit();
                }
                catch
                {
                    // Se deu erro, desfazer tudo
                    transaction.Rollback();
                }
            }

            // Volta para a mesma p�gina para fazer outro movimento se quiser
            return RedirectToAction("Index");
        }

        // 3. P�GINA DE HIST�RICO
        public IActionResult Historico()
        {
            List<MovimentoDisplay> historico = new List<MovimentoDisplay>();

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                // Esta query � "monstruosa" mas necess�ria: 
                // Junta a tabela de movimentos com Armas, Unidades (2 vezes!) e Militares
                string sql = @"
            SELECT 
                M.id_movimento, 
                A.numero_serie, 
                M.tipo_movimento, 
                U_Origem.nome AS nome_origem, 
                U_Destino.nome AS nome_destino, 
                M.data_movimento, 
                Mil.nome AS nome_responsavel
            FROM Movimento_Armamento M
            JOIN Arma A ON M.id_arma = A.id_arma
            JOIN Unidade_Militar U_Origem ON M.id_origem = U_Origem.id_unidade
            JOIN Unidade_Militar U_Destino ON M.id_destino = U_Destino.id_unidade
            LEFT JOIN Militar Mil ON M.autorizacao = Mil.id_militar
            ORDER BY M.data_movimento DESC"; // Os mais recentes primeiro

                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            MovimentoDisplay mov = new MovimentoDisplay();
                            mov.Id = (int)reader["id_movimento"];
                            mov.NumeroSerieArma = reader["numero_serie"].ToString();
                            mov.TipoMovimento = reader["tipo_movimento"].ToString();
                            mov.Origem = reader["nome_origem"].ToString();
                            mov.Destino = reader["nome_destino"].ToString();
                            mov.DataMovimento = (DateTime)reader["data_movimento"];

                            // Se n�o tiver respons�vel (null), pomos "Sistema"
                            mov.Responsavel = reader["nome_responsavel"] == DBNull.Value ? "Sistema" : reader["nome_responsavel"].ToString();

                            historico.Add(mov);
                        }
                    }
                }
            }

            return View(historico);
        }
    }
}