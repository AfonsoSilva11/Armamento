using GestaoArmamentoWeb.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using System.Collections.Generic;
using System.Diagnostics;

namespace GestaoArmamentoWeb.Controllers
{
    public class HomeController : Controller
    {
        // A tua Connection String
        string connectionString = "Server=DESKTOP-EL5VTH4;Database=GestaoArmamento;Trusted_Connection=True;MultipleActiveResultSets=true;TrustServerCertificate=True";

        public IActionResult Index()
{
    DashboardViewModel stats = new DashboardViewModel();

    using (SqlConnection conn = new SqlConnection(connectionString))
    {
        conn.Open();
        
        // Query m�ltipla para contar tudo de uma vez
        string sql = @"
            SELECT 
                (SELECT COUNT(*) FROM Arma) as Total,
                (SELECT COUNT(*) FROM Arma WHERE estado = 'Operacional') as Operacionais,
                (SELECT COUNT(*) FROM Arma WHERE estado = 'Em Manuten��o') as Manutencao,
                (SELECT COUNT(*) FROM Militar) as Militares";

        using (SqlCommand cmd = new SqlCommand(sql, conn))
        {
            using (SqlDataReader reader = cmd.ExecuteReader())
            {
                if (reader.Read())
                {
                    stats.TotalArmas = (int)reader["Total"];
                    stats.ArmasOperacionais = (int)reader["Operacionais"];
                    stats.ArmasEmManutencao = (int)reader["Manutencao"];
                    stats.TotalMilitares = (int)reader["Militares"];
                }
            }
        }
    }
    return View(stats);
}
    }
}