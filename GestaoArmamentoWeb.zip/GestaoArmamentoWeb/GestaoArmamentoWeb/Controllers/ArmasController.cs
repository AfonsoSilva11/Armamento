using GestaoArmamentoWeb.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using System.Collections.Generic;
using System.Diagnostics;

namespace GestaoArmamentoWeb.Controllers
{
    public class ArmasController : Controller
    {
        // A tua Connection String
        string connectionString = "Server=DESKTOP-EL5VTH4;Database=GestaoArmamento;Trusted_Connection=True;MultipleActiveResultSets=true;TrustServerCertificate=True";

        // 1. P�GINA PRINCIPAL (LISTAR ARMAS)
        public IActionResult Index()
        {
            List<Arma> listaArmas = new List<Arma>();

            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    // AGORA COM 2 JOINS: Trazemos o Tipo da arma E o Nome da Unidade
                    string sql = @"
                SELECT A.id_arma, A.numero_serie, A.estado, 
                       T.designacao, U.nome as nome_unidade
                FROM Arma A 
                JOIN Tipo_Arma T ON A.id_tipo = T.id_tipo
                JOIN Unidade_Militar U ON A.id_unidade = U.id_unidade";

                    using (SqlCommand cmd = new SqlCommand(sql, conn))
                    {
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                Arma armaTemp = new Arma();
                                armaTemp.id_arma = (int)reader["id_arma"];
                                armaTemp.numero_serie = (int)reader["numero_serie"];
                                armaTemp.estado = reader["estado"].ToString();
                                armaTemp.designacao_tipo = reader["designacao"].ToString();

                                // LER A NOVA COLUNA
                                armaTemp.nome_unidade = reader["nome_unidade"].ToString();

                                listaArmas.Add(armaTemp);
                            }
                        }
                    }
                }
            }
            catch (System.Exception ex)
            {
                Debug.WriteLine("Erro: " + ex.Message);
            }
            return View(listaArmas);
        }

        // 2. A��O DE INSERIR (SEM TRY-CATCH PARA VER O ERRO)
        [HttpPost]
        public IActionResult AdicionarArma(int numero_serie, int id_tipo, string estado, int id_unidade)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();

                    // CORRE��O: Adicionei o campo 'data_aquisicao' ao INSERT
                    string sql = @"INSERT INTO Arma 
                           (numero_serie, id_tipo, id_unidade, estado, data_aquisicao) 
                           VALUES 
                           (@serie, @tipo, @unidade, @estado, @data)";

                    using (SqlCommand cmd = new SqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@serie", numero_serie);
                        cmd.Parameters.AddWithValue("@tipo", id_tipo);
                        cmd.Parameters.AddWithValue("@unidade", id_unidade);
                        cmd.Parameters.AddWithValue("@estado", estado);

                        cmd.Parameters.AddWithValue("@data", System.DateTime.Now);

                        cmd.ExecuteNonQuery();
                    }
                }
            }
            catch (System.Exception ex)
            {
                // Dica: Podes p�r um breakpoint aqui para veres o erro exato se falhar outra vez
                Debug.WriteLine("ERRO GRAVE: " + ex.Message);
            }

            return RedirectToAction("Index");
        }
    }
}