﻿using System;

namespace GestaoArmamentoWeb.Models
{
    public class MovimentoDisplay
    {
        public int Id { get; set; }
        public string? NumeroSerieArma { get; set; }
        public string? TipoMovimento { get; set; }
        public string? Origem { get; set; }
        public string? Destino { get; set; }
        public DateTime DataMovimento { get; set; }
        public string? Responsavel { get; set; } // Nome do militar que autorizou
    }
}