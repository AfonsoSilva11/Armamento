﻿namespace GestaoArmamentoWeb.Models
{
    public class Militar
    {
        public int id_militar { get; set; }
        public string? nome { get; set; }
        public string? nome_unidade { get; set; } // Para mostrar na tabela
        public string? patente { get; set; } // Opcional, se tiveres

        // Dados para o Login (usados apenas na inserção)
        public string? username { get; set; }
        public string? email { get; set; }
    }
}