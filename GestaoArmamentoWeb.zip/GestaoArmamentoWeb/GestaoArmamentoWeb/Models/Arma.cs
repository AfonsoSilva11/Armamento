﻿namespace GestaoArmamentoWeb.Models
{
    public class Arma
    {
        public int id_arma { get; set; }
        public int numero_serie { get; set; }
        public string? estado { get; set; }
        public string? designacao_tipo { get; set; }

        // NOVO: Para guardar o nome da unidade (Ex: "Base Aérea...")
        public string? nome_unidade { get; set; }
    }
}