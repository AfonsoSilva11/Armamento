namespace GestaoArmamentoWeb.Models
{
    public class DashboardViewModel
    {
        public int TotalArmas { get; set; }
        public int ArmasOperacionais { get; set; }
        public int ArmasEmManutencao { get; set; }
        public int TotalMilitares { get; set; }
    }
}